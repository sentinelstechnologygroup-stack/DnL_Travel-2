// src/components/layout/Layout.jsx
import React from "react";
import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";

export default function Layout() {
  return (
    <div className="min-h-screen bg-background font-inter text-foreground overflow-x-hidden">
      <Navbar />
      <main className="isolate">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}