// src/components/sections/HeroSection.jsx
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Phone, Calendar } from "lucide-react";
import { motion } from "framer-motion";

export default function HeroSection({ heroImage }) {
  return (
    <section className="relative overflow-hidden bg-background">
      <div className="grid min-h-[100svh] grid-cols-1 lg:grid-cols-2">
        {/* Left Content */}
        <div className="relative z-10 flex min-h-[100svh] flex-col justify-center px-6 pb-12 pt-28 sm:px-8 md:px-10 lg:min-h-[100svh] lg:px-16 lg:pt-32 xl:px-24">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-xl"
          >
            <div className="mb-8 flex items-center gap-3">
              <div className="h-px w-12 bg-primary" />
              <span className="text-[10px] font-semibold tracking-[0.3em] text-primary">
                CONROE, TX — TRAVEL ADVISOR
              </span>
            </div>

            <h1 className="mb-6 text-4xl font-bold leading-[1.05] text-foreground sm:text-5xl lg:text-6xl xl:text-7xl">
              Your Journey,
              <br />
              <span className="text-primary">Perfectly</span>
              <br />
              Crafted.
            </h1>

            <p className="mb-10 max-w-md text-base leading-relaxed text-muted-foreground lg:text-lg">
              D&amp;L Travel Adventures specializes in personalized travel
              planning — from Caribbean getaways to European explorations and
              luxury cruises. No booking engines. Just expert guidance.
            </p>

            <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
              <Link to="/contact">
                <Button className="h-12 px-8 text-[11px] font-semibold tracking-[0.15em] text-primary-foreground bg-primary hover:bg-primary/90">
                  GET A FREE QUOTE
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>

              <a href="tel:+1-555-0123">
                <Button
                  variant="outline"
                  className="h-12 px-8 text-[11px] tracking-[0.15em] text-foreground/70 border-border hover:text-foreground hover:border-primary/50"
                >
                  <Phone className="mr-2 h-3.5 w-3.5" />
                  CALL NOW
                </Button>
              </a>

              <Link to="/contact">
                <Button
                  variant="ghost"
                  className="h-12 px-6 text-[11px] tracking-[0.15em] text-foreground/60 hover:text-primary"
                >
                  <Calendar className="mr-2 h-3.5 w-3.5" />
                  SCHEDULE CONSULT
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Right Image */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2 }}
          className="relative hidden min-h-[100svh] lg:block"
        >
          <img
            src={heroImage}
            alt="Stunning Caribbean sunset beach destination"
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
        </motion.div>
      </div>

      {/* Mobile background */}
      <div className="absolute inset-0 lg:hidden">
        <img
          src={heroImage}
          alt="Caribbean destination"
          className="h-full w-full object-cover opacity-15"
        />
        <div className="absolute inset-0 bg-background/75" />
      </div>
    </section>
  );
}